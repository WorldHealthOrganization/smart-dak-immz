# Identify groups of vaccination events for evaluation - XML Representation - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Identify groups of vaccination events for evaluation**

## : Identify groups of vaccination events for evaluation - XML Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw xml](Requirements-IMMZ.FXNREQ.130.H.xml) | [Download](Requirements-IMMZ.FXNREQ.130.H.xml)

