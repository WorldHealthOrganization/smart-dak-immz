# Create/update vaccination location record - JSON Representation - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Create/update vaccination location record**

## : Create/update vaccination location record - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](Requirements-IMMZ.FXNREQ.008.A.json) | [Download](Requirements-IMMZ.FXNREQ.008.A.json)

