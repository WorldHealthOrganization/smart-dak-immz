# Capture or update client history - JSON Representation - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Capture or update client history**

## : Capture or update client history - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](Requirements-IMMZ.FXNREQ.062.D.json) | [Download](Requirements-IMMZ.FXNREQ.062.D.json)

