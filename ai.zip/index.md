# Home - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/dak-immz/ImplementationGuide/smart.who.int.dak-immz | *Version*:1.1.1 |
| Draft as of 2026-11-18 | *Computable Name*:DakImmz |

### Summary

In accordance with WHO’s mandate to provide guidance to Member States on health policy matters, the organization, through the Immunization, Vaccines and Biologicals (IVB) department, is tasked with developing evidence-based immunization policy recommendations. The five-step pathway to advance the adoption of best clinical and data practices for immunizations is presented below.

### L1 Narrative guidelines

In order to assist programme managers develop optimal immunization programmes WHO has compiled key information on its current routine immunization recommendations into four summary tables:

* **Table 1** summarizes recommended routine immunizations for all age groups - children, adolescents, and adults. As such, it provides an overview of vaccine recommendations across the lifespan, including both primary series and booster doses.
* **Table 2** provides detailed information for routine immunizations for children, including age at first dose and intervals. It reiterates recommendations on the primary series and booster doses.
* **Table 3** has consolidated recommendations for interrupted and delayed vaccination. These irregular situations can be challenging to health workers who may not know what to do.
* **Table 4** summarizes WHO’s recommendations for the vaccination of health care workers.

It is important to note that these recommendations are only a compilation of existing WHO routine immunization recommendations in a new format. All the recommendations come from WHO Position Papers that are published in the Weekly Epidemiological Record. The tables are updated as soon as any new WHO recommendation is published.

The summary tables can be accessed [here](https://www.who.int/teams/immunization-vaccines-and-biologicals/policies/who-recommendations-for-routine-immunization---summary-tables).

### L2 Operational guidelines

Digital adaptation kits are designed to facilitate the accurate reflection of WHO’s clinical, public health and data use guidelines within the digital systems countries are adopting. DAKs are operational, software-agnostic, standardized documentation that distil clinical, public health and data use guidance into a format that can be transparently incorporated into digital systems. DAKs serve as a prerequisite for developing computable, or machine-readable, guidelines, as well as executable reference software and advanced analytics for precision health.

The DAK for immunizations and the associated implementation tools can be found here:

* [Published DAK Document](https://iris.who.int/handle/10665/380303)
* Implementation tools:

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the immunizations SMART Guidelines is yet to be published. Links will be published here as soon as they're available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the immunizations SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the immunizations SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

### Providing Feedback

 Feedback specific to this specification can provided through: 

* Clicking on one of the Feedbacks link to the right of any section header
* Sending an email to [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)
* Creating an issue on GitHub [dak-immz repository](https://github.com/WorldHealthOrganization/dak-immz)

### Disclaimer

Not available

