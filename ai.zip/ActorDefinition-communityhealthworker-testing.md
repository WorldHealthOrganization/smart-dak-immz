# Community health worker - Testing - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Community health worker**

## ActorDefinition: Community health worker - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-11-18 |

### Test Plans

**No test plans are currently available for the ActorDefinition.**

### Test Scripts

**No test scripts are currently available for the ActorDefinition.**

