# The system to provide a history of previous care (including previous vaccination records) - Testing - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **The system to provide a history of previous care (including previous vaccination records)**

## Requirements: The system to provide a history of previous care (including previous vaccination records) - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-11-18 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

