# Create client record - Testing - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Create client record**

## Requirements: Create client record - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-11-18 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

