# Lock a user out after a specified number of wrong password attempts - Testing - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Lock a user out after a specified number of wrong password attempts**

## Requirements: Lock a user out after a specified number of wrong password attempts - Testing (Experimental) 

| |
| :--- |
| Active as of 2026-11-18 |

### Test Plans

**No test plans are currently available for the Requirements.**

### Test Scripts

**No test scripts are currently available for the Requirements.**

