# Query client record - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Query client record**

## Requirements: Query client record (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/dak-immz/Requirements/IMMZ.FXNREQ.040.C | *Version*:1.1.1 |
| Active as of 2026-11-18 | *Computable Name*:Query client record |

 
**Business process** (C) client registration: Activity: Query client record: As a [Health worker](ActorDefinition-healthworker.md), I want to: 
>  
To search with wild cards (using a symbol to replace one or more characters) 
 
so that 
>  
I can find something without knowing the exact spelling 
 

