# Capture or update client history - XML Representation - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Capture or update client history**

## : Capture or update client history - XML Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw xml](Requirements-IMMZ.FXNREQ.062.D.xml) | [Download](Requirements-IMMZ.FXNREQ.062.D.xml)

