# Validate against national master facility list - JSON Representation - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Validate against national master facility list**

## : Validate against national master facility list - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](Requirements-IMMZ.FXNREQ.004.A.json) | [Download](Requirements-IMMZ.FXNREQ.004.A.json)

