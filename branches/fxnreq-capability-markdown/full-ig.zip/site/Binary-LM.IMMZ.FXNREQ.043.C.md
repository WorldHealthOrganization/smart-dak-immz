# LM.IMMZ.FXNREQ.043.C - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **LM.IMMZ.FXNREQ.043.C**

## Binary: LM.IMMZ.FXNREQ.043.C

```

{
  "resourceType": "http://smart.who.int/base/StructureDefinition/FunctionalRequirement",
  "id": "LM.IMMZ.FXNREQ.043.C",
  "activity": "Query client record",
  "actor": [
    {
      "reference": "ActorDefinition/healthworker"
    }
  ],
  "capabilityMarkdown": "the system to identify any records that may have been imported from another system",
  "benefitMarkdown": "I can verify the quality of imported data",
  "classification": [
    {
      "code": "C",
      "system": "http://smart.who.int/dak-immz/CodeSystem/FXREQBusinessProcesses"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
