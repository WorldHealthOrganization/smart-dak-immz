# Update vaccination event records - JSON Representation - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Update vaccination event records**

## : Update vaccination event records - JSON Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw json](Requirements-IMMZ.FXNREQ.140.H.json) | [Download](Requirements-IMMZ.FXNREQ.140.H.json)

