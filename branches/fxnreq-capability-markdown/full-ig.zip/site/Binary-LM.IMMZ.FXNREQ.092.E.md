# LM.IMMZ.FXNREQ.092.E - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **LM.IMMZ.FXNREQ.092.E**

## Binary: LM.IMMZ.FXNREQ.092.E

```

{
  "resourceType": "http://smart.who.int/base/StructureDefinition/FunctionalRequirement",
  "id": "LM.IMMZ.FXNREQ.092.E",
  "activity": "Generate list of clients",
  "actor": [
    {
      "reference": "ActorDefinition/healthworker"
    }
  ],
  "capabilityMarkdown": "To print the list of clients generated according to defined parameters",
  "benefitMarkdown": "I can use it when I am offline",
  "classification": [
    {
      "code": "E",
      "system": "http://smart.who.int/dak-immz/CodeSystem/FXREQBusinessProcesses"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
