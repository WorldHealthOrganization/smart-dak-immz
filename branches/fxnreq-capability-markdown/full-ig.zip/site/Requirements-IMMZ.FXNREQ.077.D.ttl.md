# Update client record - TTL Representation - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Update client record**

## : Update client record - TTL Representation

| |
| :--- |
| Active as of 2026-11-18 |

[Raw ttl](Requirements-IMMZ.FXNREQ.077.D.ttl) | [Download](Requirements-IMMZ.FXNREQ.077.D.ttl)

