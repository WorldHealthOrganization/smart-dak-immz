# LM.IMMZ.FXNREQ.036.C - SMART DAK IMMZ v1.1.1

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **LM.IMMZ.FXNREQ.036.C**

## Binary: LM.IMMZ.FXNREQ.036.C

```

{
  "resourceType": "http://smart.who.int/base/StructureDefinition/FunctionalRequirement",
  "id": "LM.IMMZ.FXNREQ.036.C",
  "activity": "Query client record",
  "actor": [
    {
      "reference": "ActorDefinition/healthworker"
    }
  ],
  "capabilityMarkdown": "To search for the client record given some demographic information",
  "benefitMarkdown": "I can find the client record if I do not have the unique ID",
  "classification": [
    {
      "code": "C",
      "system": "http://smart.who.int/dak-immz/CodeSystem/FXREQBusinessProcesses"
    }
  ]
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
